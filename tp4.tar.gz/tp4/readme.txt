deux graphs de tests sont codés dans des fichiers séparés.

structure d'un graph:
	nombre de sommet
	nom de chaque sommet
	nombre d'arete
	nom de chaque paire de sommet
	
ex:
2
a
b

1
a b
