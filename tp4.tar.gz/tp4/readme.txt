deux graphs de tests sont codés dans des fichiers séparés.


La couleur est à donner en argument du lancement du programme
Usage : java coloration nb_couleurs

structure d'un graph:
	nombre de sommet
	nom de chaque sommet
	nombre d'arete
	nom de chaque paire de sommet
	nombre d'arete de préferences
	nom de chaque paire de sommet 
	
	
ex:
2
a
b

1
a b

0 //correspond aux nombres d'arêtes de preference
